# User Credentials
host = 'localhost'
user = 'Your Username'
password = 'Your Password'
database = 'student_management'
